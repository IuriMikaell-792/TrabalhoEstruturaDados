def soma_matriz(l):
    soma = 0

    for i in range(0,len(l)):
        for j in range(0,len(l)):
            soma = soma + l[i][j]

    return soma

lista = [[1,1,1],[2,2,2],[3,3,3]]
print('Lista:')
print(lista)
print('Soma das listas:')
print(soma_matriz(lista))