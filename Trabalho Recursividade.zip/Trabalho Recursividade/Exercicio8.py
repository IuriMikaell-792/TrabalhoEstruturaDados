def menor_num(l):
    menor_num = l[0]

    for i in range(0, len(l)):
        if (l[i] < menor_num):
            menor_num = l[i]
    
    return menor_num

lista = [5,10,4,3,7,8,6,1,2,9]
print('Lista:')
print(lista)
print('Menor Número da Lista:')
print(menor_num(lista))