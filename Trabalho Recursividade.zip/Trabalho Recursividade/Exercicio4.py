def mmc(n1, n2):
    if n1 == 0 or n2 == 0:
        return 0
    else:
        return abs(n1 * n2) // mdc(n1, n2)
    
def mdc(n1, n2):
    if n2 == 0:
        return n1
    else:
        return mdc(n2, n1 % n2)
    
num1 = int(input('Digite um número: '))
num2 = int(input('Digite outro número: '))

result_mmc = mmc(num1, num2)
print('o MMC dos numeros ', num1, ' e ', num2, ' é igual a: ', result_mmc)