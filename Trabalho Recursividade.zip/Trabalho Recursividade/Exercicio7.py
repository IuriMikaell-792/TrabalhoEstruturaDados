def maior_num(l):
    maior_num = l[0]

    for i in range(0, len(l)):
        if (l[i] > maior_num):
            maior_num = l[i]
    
    return maior_num

lista = [5,10,4,3,7,8,6,1,2,9]
print('Lista:')
print(lista)
print('Maior Número da Lista:')
print(maior_num(lista))