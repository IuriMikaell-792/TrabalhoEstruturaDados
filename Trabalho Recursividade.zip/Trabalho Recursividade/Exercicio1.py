def fatorial(n):
    num_f = 1
    while n != 0:
        num_f = num_f * n
        n = n - 1
    print(num_f)

num = int(input('Digite um número: '))
print('O fatorial do número ', num, ' é:')
fatorial(num)