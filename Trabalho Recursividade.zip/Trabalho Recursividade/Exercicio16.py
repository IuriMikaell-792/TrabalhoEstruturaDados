def kMaiorNum(l, k):
    l = ordenaLista(l)
    print(l)
    kMaiorN = l[k - 1]
    return[kMaiorN]

def ordenaLista(l):
    lOrdenada = []
    menorElemento = l[0]

    for i in range(0,len(l)-1):
        menor = i
        for j in range(i+1, len(l)):
            if l[j] < l[menor]:
                menor = j
        temp = l[i]
        l[i] = l[menor]
        l[menor] = temp
    return l

lista = [8,3,1,2,4,7,6,9,5]
print(lista)
indiceMaior = int(input('Digite a posição da lista desejada: '))

posicao = kMaiorNum(lista, indiceMaior)
print(posicao)