from math import floor

def mediana(l, nItens):
    l = ordenaLista(l, nItens)
    print(l)

    if (nItens % 2 != 0):
        indiceMeio = floor(nItens / 2)
        mediana = l[indiceMeio]
    else:
        elementoMeio1 = l[floor((nItens / 2) - 1)]
        elementoMeio2 = l[floor(nItens / 2)]
        mediana = (elementoMeio1 + elementoMeio2) / 2

    return mediana

def ordenaLista(l, nItens):
    lOrdenada = []
    menorElemento = l[0]

    for i in range(0,len(l)-1):
        menor = i
        for j in range(i+1, len(l)):
            if l[j] < l[menor]:
                menor = j
        temp = l[i]
        l[i] = l[menor]
        l[menor] = temp
    return l

lista = [8,3,1,2,4,7,6,9,5]
tamanhoLista = len(lista)
print(lista)

l_mediana = mediana(lista, tamanhoLista)
print("Mediana: ", l_mediana)

print('-'*30)

lista2 = [8,3,1,2,4,7,6,5]
tamanhoLista2 = len(lista2)
print(lista2)

l_mediana2 = mediana(lista2, tamanhoLista2)
print("Mediana: ", l_mediana2)