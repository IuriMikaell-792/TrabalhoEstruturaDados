def potencia(n, p):
    num = 1

    for i in range(0, p):
        num = num * n
    
    return num

num = int(input('Digite um número: '))
pot = int(input('Digite a potencia: '))
print('Resultado: ', potencia(num, pot))