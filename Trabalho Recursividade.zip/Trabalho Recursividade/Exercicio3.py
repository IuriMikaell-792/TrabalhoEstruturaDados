def mdc(n1, n2):
    if n2 == 0:
        return n1
    else:
        return mdc(n2, n1 % n2)
    
num1 = int(input('Digite um número: '))
num2 = int(input('Digite outro número: '))

result_mdc = mdc(num1, num2)
print('o MDC dos numeros ', num1, ' e ', num2, ' é igual a: ', result_mdc)