def n_ocorrencias(l,n):
    n_ocorrencias = 0
    num_itens = len(l)

    for i in range(0,num_itens):
        if(l[i] == n):
            n_ocorrencias += 1

    return n_ocorrencias

lista = [7,54,3,1,5,4,2,3,1,5,1,21,3,5,7,8,1,6,9,3,4,7,36,5]
print('Lista:')
print(lista)
num = int(input('Digite um numero da lista: '))
print('Esse numero aparece ', n_ocorrencias(lista, num), ' vezes na lista!')