def media_lista(l):
    num_itens = len(l)
    total = 0
    media = 0

    for i in range(0, num_itens):
        total = total + l[i]

    media = total / num_itens
    return media

lista = [7,9,2,10,8,15,11]
print('Lista:')
print(lista)
print('Media da Lista:')
print(round(media_lista(lista),2))