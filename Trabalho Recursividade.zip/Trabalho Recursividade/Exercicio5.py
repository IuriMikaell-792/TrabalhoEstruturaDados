def somaDigitos(n):
    if n < 10:
        return n
    else:
        return n % 10 + somaDigitos(n // 10)
    

numero = int(input('Digite um número: '))
soma_Digitos = somaDigitos(numero)
print(soma_Digitos) 